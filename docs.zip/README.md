# Moon Detective: Night Shift

A game for the NASA Space Apps 2026 challenge **Junior Astronaut Mission Trainer**.
Keep a Moon crew safe from space radiation. Three rooms, one hidden dirt shield, five nights.
Check the rooms, dig dirt onto the roof, sleep in the safest one, then work out where the shield was thinnest.

The story is fictional. The rules map to real NASA and NOAA data: GOES proton flux, the September 2017 solar storm, and NASA's Foundation Surface Habitat layout. The in-game "For grown-ups" sheet lists every source and says what is simplified.

Made by Koundinya. Code written with Claude (Anthropic).

## Run it
```
npm install
npm run dev
```
`npm run build` makes the site in `dist/` (relative paths, works on GitHub Pages).

## Stack
Vite, TypeScript, Phaser 3. Icons: Phosphor. Font: Lexend. Pictures: NASA.

## Easy edits
- `src/config.ts`: hand arrow (size, shadow, opacity, on/off), idle-hint time, help button, intro words and button labels, caption, game colors.
- `src/style.css`: page styling. The Next/Skip bar and info sheet use CSS variables at the top of the last block (`--accent`, `--btn-radius`, ...).

# GitHub Pages: set Settings > Pages > Deploy from a branch > main > /docs
